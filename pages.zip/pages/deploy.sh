#!/bin/zsh
scp -r * students:/home/students/inf/f/fb394112/public_html/space_dealer