function toggleItemsWindow() {
    var itemsWindow = document.getElementById("items-window");
    toggleWindow(itemsWindow);
}
