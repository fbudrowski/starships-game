function toggleItemsWindow(){
    let itemsWindow = document.getElementById("items-window");
    toggleWindow(itemsWindow);
}


