function togglePlanetsWindow(){
    let itemsWindow = document.getElementById("planets-window");
    toggleWindow(itemsWindow);
}