function togglePlanetsWindow() {
    var itemsWindow = document.getElementById("planets-window");
    toggleWindow(itemsWindow);
}
