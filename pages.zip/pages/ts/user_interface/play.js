function play() {
    document.getElementById("start-screen-overlay").style.display = "none";
    requestNickname();
}
